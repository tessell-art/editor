package io.github.scala_tessella.dcel.structure

import io.github.scala_tessella.dcel.Utils.{associate, sequence}
import io.github.scala_tessella.dcel.*
import io.github.scala_tessella.dcel.geometry.AngleDegree
import io.github.scala_tessella.dcel.structure.Utils.breadthFirstSearch

/** Represents a single face in the DCEL.
  *
  * @param id
  *   A unique identifier for the face.
  * @param outerComponent
  *   An optional reference to one of the half-edges on the face's outer boundary.
  * @param innerComponents
  *   A list of optional references to half-edges, one for each inner boundary (hole).
  */
final class Face(
    val id: FaceId,
    private[dcel] var outerComponent: Option[HalfEdge] = None,
    private[dcel] var innerComponents: List[Option[HalfEdge]] = Nil
):
  override def equals(obj: Any): Boolean =
    obj match
      case that: Face => this.id.value == that.id.value
      case _          => false

  override def hashCode(): Int = id.value.hashCode

  override def toString: String =
    val validationErrorSuffix =
      validate().toErrorSuffix
    s"Face ${id.toPrefixedString}$validationErrorSuffix"

  def isOuter: Boolean =
    id == FaceId.outerId

  // Area calculation
  def area: Either[TopologyError, BigDecimal] =
    getVertices.map: vertices =>
      vertices
        .map:
          _.coords
        .area

  private[dcel] def areaUnsafe: BigDecimal =
    getVerticesUnsafe
      .map:
        _.coords
      .area

  def hasHoles: Boolean =
    innerComponents.nonEmpty

  def validate(): Either[IncompleteError, Unit] =
    val emptyOuterError   =
      List(
        Option.when(outerComponent.isEmpty)("Missing outer component edge")
      ).flatten
    val missingInnerError =
      if innerComponents.exists: maybeHalfEdge =>
          maybeHalfEdge.isEmpty
      then
        List("One or more inner component edge references are missing")
      else
        Nil
    emptyOuterError ::: missingInnerError match
      case Nil    => Right(())
      case errors => Left(IncompleteError(errors.mkString(", ")))

  private[dcel] def getVerticesUnsafe: List[Vertex] =
    outerComponent.get.faceTraversalUnsafe: halfEdge =>
      halfEdge.origin

  /** Get all vertices that form the boundary of a face. Returns vertices in the order they appear around the
    * face boundary.
    */
  def getVertices: Either[TopologyError, List[Vertex]] =
    outerComponent match
      case None            => Right(List.empty)
      case Some(startEdge) =>
        startEdge.faceTraversal: halfEdge =>
          halfEdge.origin

  private[dcel] def halfEdgesUnsafe: List[HalfEdge] =
    outerComponent.get.faceTraversalUnsafe()

  /** Get all half-edges forming a face loop.
    */
  def halfEdges: Either[TopologyError, List[HalfEdge]] =
    outerComponent match
      case None        => Right(List.empty)
      case Some(start) => start.faceTraversal()

  private[dcel] def anglesUnsafe: List[AngleDegree] =
    halfEdgesUnsafe.map:
      _.angle.get

  def angles: Either[TilingError, List[AngleDegree]] =
    halfEdges
      .flatMap: edges =>
        edges
          .map:
            _.angle.toRight(GeometryError("Cannot find interior angle"))
          .sequence

  private[dcel] def hasEqualAnglesUnsafe: Boolean =
    anglesUnsafe.toSet.size == 1

  /** Checks if the interior angles of the face are all equal. */
  def hasEqualAngles: Either[TilingError, Boolean] =
    angles.map: interiorAngles =>
      interiorAngles.toSet.size == 1

object Face:

  def apply(
      id: FaceId,
      outerComponent: Option[HalfEdge] = None,
      innerComponents: List[Option[HalfEdge]] = Nil
  ): Face =
    new Face(id, outerComponent, innerComponents)

  def outer: Face = Face(FaceId.outerId)

  extension (faces: List[Face])

    def adjacencyMapUnsafe: Map[Face, List[Face]] =
      val faceSet = faces.toSet
      faces.associate: face =>
        face
          .halfEdges.toOption.get
          .flatMap: halfEdge =>
            for
              twin         <- halfEdge.twin
              incidentFace <- twin.incidentFace
              if faceSet.contains(incidentFace)
            yield incidentFace

    def isConnected: Boolean =

      if faces.isEmpty then true
      else
        val reachable = breadthFirstSearch(faces.head, adjacencyMapUnsafe)
        reachable.size == faces.size
